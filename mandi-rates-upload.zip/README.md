# Mandi Rates · ಮಂಡಿ ದರ — free price app for farmers

A one-file web app (`index.html`). The farmer:
1. picks a crop (Kannada / English),
2. taps **Find my nearest mandi** (GPS) or picks an APMC from the list,
3. enters a **sowing date** (the days to harvest are pre-filled for each crop and can be changed),

and gets:
- the **predicted rate at harvest** for that mandi, with a likely range, plus the rate 1–2 months later in case they store the crop,
- how accurate the method has been at that mandi (it is tested on that mandi's own past data),
- the actual rate in the same month in past years,
- the latest rate, whether it is high, average or low against the last 12 months, the price history, the best months to sell, and nearby mandis compared.

All prices are free government AGMARKNET data from data.gov.in ("Variety-wise Daily Market Prices", resource `35985678-0d79-46b4-9ed6-6f13308a1d24`).

## How it's set up
- A **daily GitHub Action** (`.github/workflows/update-prices.yml`) runs `scripts/update_prices.py` every evening at about 7 pm India time. It fetches new Karnataka prices with your API key and saves small files under `data/`.
- The **app** (`index.html`, served by GitHub Pages) reads only those files. Farmers' phones never call data.gov.in, so the app is fast, the key stays secret, and it keeps working if the government site is slow.
- The **API key** is kept only as a GitHub secret named `DATA_GOV_API_KEY`. Never put it in any file: this repository is public.

## Files in this repository
```
index.html                              the app
scripts/update_prices.py                daily data job (Python, no extra packages)
.github/workflows/update-prices.yml     schedule for the daily job
data/                                   created by the job — the prices the app reads
state/progress.json                     created by the job — how far each crop has been fetched
```

## Preview
Open `index.html#demo` to see the app with made-up sample prices. It shows a yellow DEMO banner.

## First run
Go to **Actions → Update mandi prices → Run workflow**. The first run loads several years of history and can take a few hours. If it reaches the time limit, it saves its progress and the next run carries on from there. After that, each daily run takes a few minutes.

Check the run log: crops marked "no Karnataka records found" either use a different name in AGMARKNET or have no data. Send the log to Claude if many crops are skipped.

**Note:** GitHub pauses scheduled jobs in repositories with no activity for 60 days. If that happens, open the Actions tab and click **Enable workflow**.

## How the harvest-price prediction works
1. Daily modal prices are averaged into monthly prices for the chosen mandi, crop and variety.
2. **Seasonal pattern:** each year's monthly prices are divided by that year's average, then the results are averaged across years. For example, onion usually comes out cheap in Mar–Apr and costly in Sep–Oct.
3. **Trend:** a straight-line trend is fitted on the last 36 months after removing the seasonal effect. The slope is halved to avoid over-reacting and capped at ±2% per month.
4. **Prediction for the harvest month** = the recent level (the last 3 months) × the trend × that month's seasonal factor.
5. **Likely range:** the method is re-run at every past month using only the data available then. It is checked against what actually happened at the same horizon. The range shown covers 8 out of 10 of those past outcomes.

The app needs at least 18 months of data at a mandi to predict. Small mandis with few reports show a message suggesting a bigger nearby mandi. This is a planning guide: it cannot know future rainfall, MSP changes or market shocks, and the app says so on screen.

## Things to adjust
- **Crop list, Kannada names and harvest durations:** see the `CROPS` and `DUR` lists in the script.
- **Another state:** change `STATE` and add that state's towns to `TOWNS`. `TOWNS` holds approximate coordinates, used to find the nearest mandi.
- **Mandi names that aren't recognised:** these fall back to their district's location. Add the name as an alias in `TOWNS`.
- **More crops or another state:** edit the `CROPS` list and `STATE` at the top of `scripts/update_prices.py`.

## Next steps if farmers like it
- Wrap it as an Android app with a free Trusted Web Activity (Bubblewrap) and list it on the Play Store.
- Add a WhatsApp or SMS price alert, for example "Onion at Annigeri crossed ₹2,500".
- Add rainfall and sowing-area data to improve predictions for the crops that need it.
